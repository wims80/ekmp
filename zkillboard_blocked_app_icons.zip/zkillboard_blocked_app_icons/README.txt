zKillboard Blocked application icon bundle

WINDOWS
-------
Use:
  windows/app-icon.ico

It contains these embedded sizes:
  16, 20, 24, 32, 40, 48, 64, 128, 256 px

For Rust, your Windows build/installer should embed app-icon.ico as the executable icon.
The individual PNGs are included for installer or packaging tools that prefer PNG.

LINUX
-----
The directory:
  linux/hicolor/<SIZE>x<SIZE>/apps/app-icon.png

is already arranged in the standard hicolor icon-theme layout.

Typical system install locations are:
  /usr/share/icons/hicolor/<SIZE>x<SIZE>/apps/app-icon.png
or per-user:
  ~/.local/share/icons/hicolor/<SIZE>x<SIZE>/apps/app-icon.png

Then a .desktop file can use:
  Icon=app-icon

Included Linux sizes:
  16, 22, 24, 32, 36, 48, 64, 72, 96, 128, 192, 256, 512 px

SOURCE
------
source/app-icon-1024-transparent.png
  Recommended master for further resizing.

source/app-icon-1024-white.png
  Same artwork with the original white background preserved.

NOTES
-----
- PNG outputs use transparency.
- The Windows ICO uses the transparent artwork too.
- If your final application has a different icon basename, rename app-icon consistently
  in the Linux hicolor folders and in your .desktop file.
