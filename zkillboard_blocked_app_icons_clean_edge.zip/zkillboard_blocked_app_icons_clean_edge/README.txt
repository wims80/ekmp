Clean-edge transparent application icon bundle

The background outside the forbidden-sign circle is fully transparent.
The mask is inset slightly inside the generated source edge to eliminate
the white anti-alias fringe visible in the previous bundle.

Windows:
  windows/app-icon.ico

Linux:
  linux/hicolor/<SIZE>x<SIZE>/apps/app-icon.png

Master:
  source/app-icon-1024-transparent.png
